#ifndef SOCIEDAD_H
#define SOCIEDAD_H

#include "Nodos.h"

/*
Cantidad máxima de cada bien o servicio según las personas de la comuna.
Los bienes tienen un factor alto porque se consumen cada turno (cada persona
consume entre 1 y 5 por turno, 3 en promedio, así que 60 alcanzan para unos
20 turnos). Los servicios no se consumen, solo bajan por emergencias, por eso
su factor es bajo.
*/
#define FACTOR_MAXIMO_BIENES 60
#define FACTOR_MAXIMO_SERVICIOS 2

/*
Al crear la sociedad, cada bien o servicio empieza con una cantidad al azar
entre este porcentaje de su máximo y el máximo completo.
*/
#define PORCENTAJE_INICIAL_MINIMO 60

/*
Umbrales para disolver una comuna. La necesidad y la satisfacción van de 0 a
99, así que una necesidad de 90 o más es "muy alta" y una satisfacción de 10
o menos es "muy baja". Basta con que se cumpla uno de los dos.
*/
#define NECESIDAD_DISOLUCION 90
#define SATISFACCION_DISOLUCION 10

// PEDIR DATOS

/*
Funcionamiento: le pide un número entero al usuario y repite la pregunta hasta que escriba uno dentro del rango. Si se acaba la entrada de datos devuelve el mínimo para no quedarse en un ciclo infinito.
Entradas: mensaje (texto de lo que se pregunta), minimo (valor mínimo permitido), maximo (valor máximo permitido)
Salidas: el número que escribió el usuario, dentro del rango
*/
int pedirCantidad(char mensaje[], int minimo, int maximo);

// ELEGIR

/*
Funcionamiento: elige al azar una cantidad exacta de comunas de la lista de comunas disponibles y las copia (solo el nombre) en una lista circular nueva. Cada comuna disponible tiene la misma probabilidad de ser elegida.
Entradas: disponibles (lista circular con todas las comunas del archivo), cantidadDisponibles (cuántas hay en esa lista), cantidadElegir (cuántas se quieren elegir)
Salidas: puntero al inicio de la lista circular con las comunas elegidas
*/
struct Comuna *elegirComunas(struct Comuna *disponibles, int cantidadDisponibles, int cantidadElegir);

/*
Funcionamiento: se queda solo con los primeros nodos de la lista de recursos y libera el resto.
Entradas: lista (inicio de la lista), cantidad (cuántos recursos se conservan, mínimo 1)
Salidas: puntero al inicio de la lista recortada
*/
struct Recursos *recortarRecursos(struct Recursos *lista, int cantidad);

/*
Funcionamiento: se queda solo con los primeros nodos de la lista de servicios y libera el resto.
Entradas: lista (inicio de la lista), cantidad (cuántos servicios se conservan, mínimo 1)
Salidas: puntero al inicio de la lista recortada
*/
struct Servicios *recortarServicios(struct Servicios *lista, int cantidad);

// REPARTIR Y ASIGNAR

/*
Funcionamiento: reparte todas las personas entre las comunas, pasando cada nodo de la lista general a la lista de su comuna. Las cantidades son distintas entre comunas (cada una recibe cerca del promedio de lo que queda, más o menos la mitad) y todas reciben al menos una persona. La última comuna recibe las que sobren. Al terminar, la lista general queda vacía y su puntero ya no se debe usar.
Entradas: inicio (lista circular de comunas), cantidadComunas (cuántas comunas hay), personas (lista general de personas)
Salidas: ninguna (cada comuna queda con su lista de personas)
*/
void repartirPersonas(struct Comuna *inicio, int cantidadComunas, struct Persona *personas);

/*
Funcionamiento: le da a una comuna su propia copia de cada recurso del catálogo. El máximo se calcula según las personas de la comuna y la cantidad inicial es al azar entre el porcentaje inicial mínimo y el máximo.
Entradas: comuna (comuna que recibe los recursos), catalogo (lista base de recursos)
Salidas: ninguna (la comuna queda con su lista de recursos)
*/
void asignarRecursos(struct Comuna *comuna, struct Recursos *catalogo);

/*
Funcionamiento: le da a una comuna su propia copia de cada servicio del catálogo, conservando el oficio de cada uno. El máximo se calcula según las personas de la comuna y la cantidad inicial es al azar entre el porcentaje inicial mínimo y el máximo.
Entradas: comuna (comuna que recibe los servicios), catalogo (lista base de servicios)
Salidas: ninguna (la comuna queda con su lista de servicios)
*/
void asignarServicios(struct Comuna *comuna, struct Servicios *catalogo);

// CREAR LA SOCIEDAD

/*
Funcionamiento: crea la sociedad completa. Lee los archivos personas, bienes, servicios y comunas, le pregunta al usuario cuántas comunas, bienes y servicios quiere, reparte las personas, y le da a cada comuna sus bienes y servicios con sus máximos y cantidades iniciales.
Entradas: ninguna (los datos los pide al usuario)
Salidas: puntero al inicio de la lista circular de comunas, o NULL si no se pudo crear (por ejemplo, si falta un archivo)
*/
struct Comuna *crearSociedad(void);

// DISOLVER

/*
Funcionamiento: revisa si una comuna debe disolverse: su necesidad llegó a NECESIDAD_DISOLUCION o más, o su satisfacción bajó a SATISFACCION_DISOLUCION o menos. Solo revisa los índices que ya tiene la comuna, no los recalcula.
Entradas: comuna (comuna que se quiere revisar)
Salidas: 1 si debe disolverse, 0 si no
*/
int comunaDebeDisolverse(struct Comuna *comuna);

/*
Funcionamiento: disuelve una comuna: todas sus personas pasan a la comuna siguiente (los servicios se van con ellas, porque dependen de las personas), sus bienes se abandonan (se liberan sin pasar a ningun lado), y el nodo se saca de la lista circular y se libera. Si la comuna disuelta era una de las administradas, la administracion pasa a otra comuna autonoma. No disuelve nada si quedarian 3 comunas o menos, porque no se podrian administrar las 3 que pide el proyecto.
Entradas: inicio (puntero a cualquier comuna de la lista circular),
          cantidadComunas (puntero a la cantidad total de comunas, se actualiza si se disuelve),
          comuna (la comuna que se quiere disolver),
          comunaActual (puntero a la comuna administrada que tiene seleccionada el usuario, se actualiza si era la disuelta)
Salidas: puntero al nuevo inicio de la lista circular (cambia si la comuna disuelta era el inicio)
*/
struct Comuna *disolverComuna(struct Comuna *inicio, int *cantidadComunas, struct Comuna *comuna, struct Comuna **comunaActual);

// LIBERAR

/*
Funcionamiento: recorre la lista de personas y libera la memoria de cada nodo, uno por uno.
Entradas: lista (inicio de la lista)
Salidas: ninguna (libera memoria)
*/
void liberarPersonas(struct Persona *lista);

/*
Funcionamiento: libera toda la lista circular de comunas, incluyendo las listas de personas, recursos y servicios de cada una.
Entradas: inicio (inicio de la lista circular)
Salidas: ninguna (libera memoria)
*/
void liberarComunas(struct Comuna *inicio);

#endif
#include <stdlib.h>
#include "Indices.h"
#include "Busqueda.h"

float formulaSatisfaccion(struct Comuna *comuna) {
    /*
    funcionamiento: Calcula la satisfacción de una comuna en base a sus recursos y servicios disponibles, así como la cantidad de emergencias que se han producido
    entradas: comuna (puntero a la comuna de la cual se quiere calcular la satisfacción)
    salidas: satisfacción
    */
    struct Recursos *r = comuna->bienes;
    struct Servicios *s = comuna->servicios;
    int personas = 0;
    int total_recursos = 0;
    int total_servicios = 0;
    int suma_puntos_recursos = 0;
    int emergencias_recursos = 0;
    int suma_puntos_servicios = 0;
    int emergencias_servicios = 0;
    int total_emergencias = 0;
    int resultados_validos = 0;
    float tope = 0;
    float valores_funcionales = 0;
    float satisfaccion = 0;

    personas = recorrerPersonas(comuna->personas);

    // Una comuna sin personas no tiene quien pueda estar satisfecho (y así se evitan divisiones entre 0 más adelante)
    if (personas == 0) {
        return 0;
    }

    // Contar el total de recursos
    while (r != NULL) {
        total_recursos = total_recursos + 1;
        r = r->siguiente;
    }

    // Contar el total de servicios
    while (s != NULL) {
        total_servicios = total_servicios + 1;
        s = s->siguiente;
    }

    // Calcular los puntos y emergencias para recursos y servicios
    calcularPuntosRecursos(comuna->bienes, personas, &suma_puntos_recursos, &emergencias_recursos);
    calcularPuntosServicios(comuna->servicios, personas, &suma_puntos_servicios, &emergencias_servicios);

    // Calcular el total de emergencias
    total_emergencias = emergencias_recursos + emergencias_servicios;

    // Calcular el tope de satisfacción basado en el número de emergencias
    if (total_emergencias == 0) {
        tope = 99;
    } else {
        tope = 50 - 5 * (total_emergencias - 1);
        if (tope < 0) {
            tope = 0;
        }
    }

    // Calcular los resultados válidos (total de recursos y servicios menos las emergencias)
    resultados_validos = (total_recursos - emergencias_recursos) + (total_servicios - emergencias_servicios);

    if (resultados_validos == 0) {
        satisfaccion = tope;
    } else {
        valores_funcionales = (float)(suma_puntos_recursos + suma_puntos_servicios) / (2 * resultados_validos);
        satisfaccion = valores_funcionales * tope;
    }

    return satisfaccion;
}

float calcularSatisfaccion(struct Comuna *actual, int cantidadComunas) {
    /*
    Funcionamiento: Calcula la satisfacción de una comuna en base a su propia satisfacción y la de sus comunas vecinas
    Entradas: actual (puntero a la comuna de la cual se quiere calcular la satisfacción y cantidadComunas (número total de comunas en la lista circular)
    Salidas: satisfacción final
    */
    float propia = 0;
    float suma_vecinas = 0;
    int cantidad_vecinas = 0;
    float promedio_vecinas = 0;
    float satisfaccion_final = 0;

    // Calcular la satisfacción propia de la comuna actual
    propia = formulaSatisfaccion(actual);

    // Calcular la satisfacción de las comunas vecinas
    if (cantidadComunas >= 5) { // Si hay 5 o más comunas, se consideran las 4 vecinas más cercanas
        suma_vecinas = suma_vecinas + formulaSatisfaccion(avanzarComunas(actual, cantidadComunas - 2, cantidadComunas)); // Vecina anterior
        suma_vecinas = suma_vecinas + formulaSatisfaccion(avanzarComunas(actual, cantidadComunas - 1, cantidadComunas)); // Vecina anterior
        suma_vecinas = suma_vecinas + formulaSatisfaccion(avanzarComunas(actual, 1, cantidadComunas)); // Vecina siguiente
        suma_vecinas = suma_vecinas + formulaSatisfaccion(avanzarComunas(actual, 2, cantidadComunas)); // Vecina siguiente
        cantidad_vecinas = 4;
    } else if (cantidadComunas == 4) { // Si hay 4 comunas, se consideran las 3 vecinas más cercanas
        suma_vecinas = suma_vecinas + formulaSatisfaccion(avanzarComunas(actual, cantidadComunas - 2, cantidadComunas)); // Vecina anterior
        suma_vecinas = suma_vecinas + formulaSatisfaccion(avanzarComunas(actual, cantidadComunas - 1, cantidadComunas)); // Vecina anterior
        suma_vecinas = suma_vecinas + formulaSatisfaccion(avanzarComunas(actual, 1, cantidadComunas)); // Vecina siguiente
        cantidad_vecinas = 3;
    } else if (cantidadComunas == 3) { // Si hay 3 comunas, se consideran las 2 vecinas más cercanas
        suma_vecinas = suma_vecinas + formulaSatisfaccion(avanzarComunas(actual, cantidadComunas - 1, cantidadComunas)); // Vecina anterior
        suma_vecinas = suma_vecinas + formulaSatisfaccion(avanzarComunas(actual, 1, cantidadComunas)); // Vecina siguiente
        cantidad_vecinas = 2;
    } else if (cantidadComunas == 2) { // Si hay 2 comunas, se considera la única vecina
        suma_vecinas = suma_vecinas + formulaSatisfaccion(avanzarComunas(actual, 1, cantidadComunas)); // Vecina siguiente
        cantidad_vecinas = 1;
    }

    if (cantidad_vecinas == 0) { // Si no hay comunas vecinas, la satisfacción final es la propia
        satisfaccion_final = propia;

    // Si hay comunas vecinas, se calcula el promedio de sus satisfacciones y se combina con la propia
    } else {
        promedio_vecinas = suma_vecinas / cantidad_vecinas;
        satisfaccion_final = propia * 0.7 + promedio_vecinas * 0.3;
    }

    // Actualizar la satisfacción de la comuna actual
    actual->satisfaccion = satisfaccion_final;

    return satisfaccion_final;
}

float calcularReciprocidad(struct Comuna *comuna) {
    /*
    Funcionamiento: calcula el balance entre los regalos dados y recibidos por una comuna. Es 1 si solo dio, -1 si solo recibió y 0 si dio y recibió lo mismo o si no hay regalos.
    Entradas: comuna (puntero a la comuna de la cual se quiere calcular la reciprocidad)
    Salidas: balance entre -1 y 1
    */
    int total = comuna->regalosDados + comuna->regalosRecibidos;

    if (total == 0) {
        return 0;
    }

    return (float)(comuna->regalosDados - comuna->regalosRecibidos) / total;
}

float calcularNecesidadLocal(struct Comuna *comuna) {
    /*
    Funcionamiento: Calcula la necesidad propia de una comuna en base a cuánto le falta para llegar al máximo de sus recursos y servicios, sin tomar en cuenta a otras comunas ni los regalos
    Entradas: comuna (puntero a la comuna de la cual se quiere calcular la necesidad local)
    Salidas: necesidad local
    */
    struct Recursos *r = comuna->bienes;
    struct Servicios *s = comuna->servicios;
    int suma_maximo_recursos = 0;
    int suma_cantidad_recursos = 0;
    int suma_maximo_servicios = 0;
    int suma_cantidad_servicios = 0;
    float faltante_recursos = 0;
    float faltante_servicios = 0;
    float promedio_faltantes = 0;

    // Calcular la suma de las cantidades máximas y actuales de recursos
    while (r != NULL) {
        suma_maximo_recursos = suma_maximo_recursos + r->cantidadMaxima;
        suma_cantidad_recursos = suma_cantidad_recursos + r->cantidad;
        r = r->siguiente;
    }

    // Calcular la suma de las cantidades máximas y actuales de servicios
    while (s != NULL) {
        suma_maximo_servicios = suma_maximo_servicios + s->cantidadMaxima;
        suma_cantidad_servicios = suma_cantidad_servicios + s->cantidad;
        s = s->siguiente;
    }

    // Si la suma de máximos es 0 (no hay recursos o servicios, o todavía no se asignaron máximos), el faltante queda en 0 para no dividir entre 0
    if (suma_maximo_recursos > 0) {
        faltante_recursos = (float)(suma_maximo_recursos - suma_cantidad_recursos) / suma_maximo_recursos;
    }
    if (suma_maximo_servicios > 0) {
        faltante_servicios = (float)(suma_maximo_servicios - suma_cantidad_servicios) / suma_maximo_servicios;
    }

    // Calcular el promedio de los faltantes de recursos y servicios
    promedio_faltantes = (faltante_recursos + faltante_servicios) / 2;

    return 99 * promedio_faltantes;
}

float valorComunaVecina(struct Comuna *vecina, int tipo) {
    /*
    Funcionamiento: Calcula el valor de una comuna vecina que se necesita para promediar. No modifica la comuna
    Entradas: vecina (puntero a la comuna vecina),
              tipo (1 = necesidad local, 2 = satisfaccion propia)
    Salidas: necesidad local si el tipo es 1, satisfaccion propia en cualquier otro caso
    */
    if (tipo == 1) {
        return calcularNecesidadLocal(vecina);
    }

    return formulaSatisfaccion(vecina);
}

float promedioVecinas(struct Comuna *actual, int cantidadComunas, int tipo) {
    /*
    Funcionamiento: Calcula el promedio de la necesidad local o de la satisfaccion propia de las comunas vecinas, con las mismas vecinas que usa calcularSatisfaccion
    Entradas: actual (puntero a la comuna de la cual se buscan las vecinas),
              cantidadComunas (numero total de comunas en la lista circular),
              tipo (1 = necesidad local, 2 = satisfaccion propia)
    Salidas: promedio de las vecinas, o -1 si no hay comunas vecinas
    */
    float suma_vecinas = 0;
    int cantidad_vecinas = 0;

    if (cantidadComunas >= 5) { // Si hay 5 o mas comunas, se consideran las 4 vecinas mas cercanas
        suma_vecinas = suma_vecinas + valorComunaVecina(avanzarComunas(actual, cantidadComunas - 2, cantidadComunas), tipo); // Vecina anterior
        suma_vecinas = suma_vecinas + valorComunaVecina(avanzarComunas(actual, cantidadComunas - 1, cantidadComunas), tipo); // Vecina anterior
        suma_vecinas = suma_vecinas + valorComunaVecina(avanzarComunas(actual, 1, cantidadComunas), tipo); // Vecina siguiente
        suma_vecinas = suma_vecinas + valorComunaVecina(avanzarComunas(actual, 2, cantidadComunas), tipo); // Vecina siguiente
        cantidad_vecinas = 4;
    } else if (cantidadComunas == 4) { // Si hay 4 comunas, se consideran las 3 vecinas mas cercanas
        suma_vecinas = suma_vecinas + valorComunaVecina(avanzarComunas(actual, cantidadComunas - 2, cantidadComunas), tipo); // Vecina anterior
        suma_vecinas = suma_vecinas + valorComunaVecina(avanzarComunas(actual, cantidadComunas - 1, cantidadComunas), tipo); // Vecina anterior
        suma_vecinas = suma_vecinas + valorComunaVecina(avanzarComunas(actual, 1, cantidadComunas), tipo); // Vecina siguiente
        cantidad_vecinas = 3;
    } else if (cantidadComunas == 3) { // Si hay 3 comunas, se consideran las 2 vecinas mas cercanas
        suma_vecinas = suma_vecinas + valorComunaVecina(avanzarComunas(actual, cantidadComunas - 1, cantidadComunas), tipo); // Vecina anterior
        suma_vecinas = suma_vecinas + valorComunaVecina(avanzarComunas(actual, 1, cantidadComunas), tipo); // Vecina siguiente
        cantidad_vecinas = 2;
    } else if (cantidadComunas == 2) { // Si hay 2 comunas, se considera la unica vecina
        suma_vecinas = suma_vecinas + valorComunaVecina(avanzarComunas(actual, 1, cantidadComunas), tipo); // Vecina siguiente
        cantidad_vecinas = 1;
    }

    if (cantidad_vecinas == 0) {
        return -1;
    }

    return suma_vecinas / cantidad_vecinas;
}

float calcularNecesidad(struct Comuna *comuna, int cantidadComunas) {
    /*
    Funcionamiento: Calcula la necesidad de una comuna a partir de su necesidad local, la necesidad y la satisfaccion de sus comunas vecinas, y su reciprocidad
    Entradas: comuna (puntero a la comuna de la cual se quiere calcular la necesidad),
              cantidadComunas (numero total de comunas en la lista circular)
    Salidas: necesidad
    */
    float necesidad = 0;
    float necesidad_local = 0;
    float necesidad_base = 0;
    float promedio_necesidad_vecinas = 0;
    float promedio_satisfaccion_vecinas = 0;
    float reciprocidad = 0;
    float necesidad_reciprocidad = 0;

    necesidad_local = calcularNecesidadLocal(comuna);
    promedio_necesidad_vecinas = promedioVecinas(comuna, cantidadComunas, 1);
    promedio_satisfaccion_vecinas = promedioVecinas(comuna, cantidadComunas, 2);

    // Si no hay vecinas, la necesidad base es solo la local. Si hay, se combina con la de las vecinas
    if (promedio_necesidad_vecinas < 0) {
        necesidad_base = necesidad_local;
    } else {
        necesidad_base = 0.6 * necesidad_local + 0.2 * promedio_necesidad_vecinas + 0.2 * (99 - promedio_satisfaccion_vecinas);
    }

    // Solo aumenta la necesidad si la comuna recibio mas regalos de los que dio
    reciprocidad = calcularReciprocidad(comuna);
    if (reciprocidad < 0) {
        necesidad_reciprocidad = 99 * (-reciprocidad);
    }

    necesidad = necesidad_base + 0.15 * necesidad_reciprocidad;
    if (necesidad > 99) {
        necesidad = 99;
    }

    // Actualizar la necesidad de la comuna
    comuna->necesidad = necesidad;

    return necesidad;
}

void actualizarIndices(struct Comuna *inicio, int cantidadComunas) {
    /*
    Funcionamiento: recorre todas las comunas de la lista circular y les actualiza su necesidad y satisfacción usando las fórmulas.
    Entradas: inicio (puntero a cualquier comuna de la lista circular),
              cantidadComunas (número total de comunas en la lista)
    Salidas: ninguna (actualiza directamente cada comuna->necesidad y comuna->satisfaccion)
    */
    struct Comuna *actual = inicio;
    struct Comuna *comuna_inicial = inicio;

    while (1) {
        calcularNecesidad(actual, cantidadComunas);
        calcularSatisfaccion(actual, cantidadComunas);

        actual = actual->siguiente;

        if (actual == comuna_inicial) {
            break;
        }
    }
}
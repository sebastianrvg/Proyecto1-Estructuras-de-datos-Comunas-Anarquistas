#ifndef SOCIEDAD_H
#define SOCIEDAD_H

/*
Funciones que arman la sociedad completa
Pendiente de implementar, es lo último antes del main entonces sí
*/

#endif

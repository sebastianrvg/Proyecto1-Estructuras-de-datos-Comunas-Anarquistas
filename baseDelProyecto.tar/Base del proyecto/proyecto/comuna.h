#ifndef COMUNA_H
#define COMUNA_H

/*
Estructura y funciones de Comuna (lista doblemente enlazada).
Pendiente.
*/

#endif

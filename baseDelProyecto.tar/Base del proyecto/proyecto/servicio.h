#ifndef SERVICIO_H
#define SERVICIO_H

/*
Estructura y func
Pendiente de implementar.
*/

#endif

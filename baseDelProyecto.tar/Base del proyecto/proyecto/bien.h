#ifndef BIEN_H
#define BIEN_H

/*
Estructura y funciones de lo bienes, pendiente.
*/

#endif

#include <stdio.h>
#include "persona.h"
#include "bien.h"
#include "servicio.h"
#include "comuna.h"
#include "sociedad.h"

/*
Funcionamiento: punto de entrada del programa. Por ahora solo confirma que
el proyecto compila; el menu y el ciclo de turnos se agregan en commits posteriores.
Entradas: ninguna
Salidas: 0 si el programa termina correctamente
*/
int main() {
    printf("Simulacion de comunas anarquista\n");
    return 0;
}
